from flask import Flask, request, jsonify

app = Flask(__name__)

# Dados mock para simular um banco de dados
listings = [
    {"id": 1, "user_id": 1, "energy_amount": 100, "price": 50},
    {"id": 2, "user_id": 2, "energy_amount": 200, "price": 90}
]

transactions = []

users = [
    {"id": 1, "name": "User 1"},
    {"id": 2, "name": "User 2"}
]

# Endpoints para gerenciar ofertas de energia
@app.route('/listings', methods=['GET', 'POST'])
def handle_listings():
    if request.method == 'GET':
        return jsonify(listings)
    elif request.method == 'POST':
        new_listing = request.json
        listings.append(new_listing)
        return jsonify(new_listing), 201

@app.route('/listings/<int:listing_id>', methods=['PUT', 'DELETE'])
def handle_single_listing(listing_id):
    listing = next((l for l in listings if l["id"] == listing_id), None)
    if not listing:
        return jsonify({"error": "Listing not found"}), 404

    if request.method == 'PUT':
        data = request.json
        listing.update(data)
        return jsonify(listing)
    elif request.method == 'DELETE':
        listings.remove(listing)
        return jsonify({"message": "Listing deleted successfully"}), 200

# Endpoints para gerenciar transações de energia
@app.route('/transactions', methods=['GET', 'POST'])
def handle_transactions():
    if request.method == 'GET':
        return jsonify(transactions)
    elif request.method == 'POST':
        new_transaction = request.json
        transactions.append(new_transaction)
        return jsonify(new_transaction), 201

# Endpoints para gerenciar usuários
@app.route('/users', methods=['GET', 'POST'])
def handle_users():
    if request.method == 'GET':
        return jsonify(users)
    elif request.method == 'POST':
        new_user = request.json
        users.append(new_user)
        return jsonify(new_user), 201

@app.route('/users/<int:user_id>', methods=['GET', 'PUT', 'DELETE'])
def handle_single_user(user_id):
    user = next((user for user in users if user['id'] == user_id), None)
    if not user:
        return jsonify({'message': 'User not found'}), 404

    if request.method == 'GET':
        return jsonify(user)
    elif request.method == 'PUT':
        data = request.json
        if not isinstance(user, dict):  # Verifique se o usuário é um dicionário
            return jsonify({'message': 'An error occurred while updating the user'}), 500
        user.update(data)
        return jsonify(user)
    elif request.method == 'DELETE':
        users.remove(user)
        return jsonify({"message": "User deleted successfully"}), 200


if __name__ == '__main__':
    app.run(debug=True)
